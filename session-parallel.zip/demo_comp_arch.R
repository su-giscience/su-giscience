n = 400000

f1 = function() {
  m = matrix(runif(1:n), ncol=4)
  means = c()
  for (i in 1:nrow(m)) {
    means = c(means, mean(m[i,]))
  }
  return(means)
}

f2 = function() {
  m = matrix(runif(1:n), ncol=4)
  means = vector("numeric", nrow(m))
  for (i in sample(1:nrow(m))) {
    means[i] = mean(m[i,])
  }
  return(means)
}


# foo = microbenchmark::microbenchmark(
#   f1(),
#   f2(),
#   times=20, unit="s")
# plot(foo)






f3 = function() {
  m = matrix(runif(1:n), ncol=4)
  apply(m, 1, mean)
}

f23 = function() {
  m = matrix(runif(1:n), ncol=4)
  sapply(1:nrow(m), function(i){
    mean(m[i,])
  })
}

foo = microbenchmark::microbenchmark(
  f2(),
  f3(),
  f23(),
  times=20, unit="s")
plot(foo)


n = 400000

clf1  = parallel::makeCluster(1,  type="FORK")
clf2  = parallel::makeCluster(2,  type="FORK")
clf3  = parallel::makeCluster(3,  type="FORK")
clf4  = parallel::makeCluster(4,  type="FORK")
clf8  = parallel::makeCluster(8,  type="FORK")
clf12  = parallel::makeCluster(12,  type="FORK")
clf16  = parallel::makeCluster(16,  type="FORK")


f4 = function(cl) {
  m = matrix(runif(1:n), ncol=4)
  parallel::parApply(cl, m, 1, mean)
}

foo = microbenchmark::microbenchmark(
  f3(), 
  f4(clf1), 
  f4(clf2), 
  f4(clf3), 
  f4(clf4), 
  # f4(clf8),
  # f4(clf12),
  # f4(clf16),
  times=5, unit="s")
plot(foo)
